package com.example.lab6_task1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
